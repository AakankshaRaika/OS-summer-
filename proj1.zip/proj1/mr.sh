g++ -o main main.cpp
./main -a -s -p 6000 2>&1
