/*
 * soc.c - program to open sockets to remote machines
 *
 * $Author: kensmith $
 * $Id: soc.c 6 2009-07-03 03:18:54Z kensmith $
 */

static char svnid[] = "$Id: soc.c 6 2009-07-03 03:18:54Z kensmith $";

#define BUF_LEN 8192

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <netinet/in.h>
#include <inttypes.h>
#include <unistd.h>
#include <netdb.h>
#include <iostream>
#include <memory>
#include <queue>
#include <mutex>
#include <pthread.h>
#include <unordered_map>
#include <sys/stat.h>
#include <dirent.h>

using namespace std;

//struct to capture the details of the request

struct FILE_DETAILS {
    time_t arv_time;
    int file_size;
    string file_name;
    bool GET = false;
    int client_socket;
};

//struct for the header information of the response

struct HTTP_HEADER {
    time_t resp_time; // strftime to change this to http date time format
    string server;
    time_t last_modified;
    string content_type;
    int content_len;
};

//struct for the response - header + content

struct HTTP_RESPONSE {
    struct HTTP_HEADER header;
    FILE *content;
};

//hashtable to keep a list of files in the directory and their sizes
unordered_map<string, int> dir_listing;

char *progname;
char buf[BUF_LEN];

void usage();
int setup_server();
//function to add request to the ready queue
void insertInQueue(FILE_DETAILS *file);
//function for the scheduler thread
void scheduler();
//function for the worker thread
void worker();
//function to format the date according to the HTTP date time format
string formatDate(time_t *time);

struct sockaddr_in remote;
int s, sock, ch, server, done, bytes, n;
int soctype = SOCK_STREAM;
string dir = "/home/jayati/";
char *host = NULL;
char *port = NULL;
extern char *optarg;
extern int optind;
socklen_t len = sizeof (remote);
bool sjf = false;
mutex m; //to protect the ready_queue
mutex p; //to protect the shared variable pass_req
queue<pthread_t> thread_pool;
FILE_DETAILS *pass_req;

//Orders the ready queue

struct Order {
    //if fcfs order by the arrival times else order by filesize and arrival times

    bool operator()(const FILE_DETAILS &req1, const FILE_DETAILS &req2) {
        if (!sjf)
            return difftime(req1.arv_time, req2.arv_time) < 0;
        else if (req1.file_size == req2.file_size)
            return difftime(req1.arv_time, req2.arv_time) < 0;
        return req1.file_size < req2.file_size;
    }
};
priority_queue<FILE_DETAILS, vector<FILE_DETAILS>, Order> ready_queue;

int
main(int argc, char *argv[]) {
    fd_set ready;
    struct sockaddr_in msgfrom;
    socklen_t msgsize;
    int opt = 1;

    union {
        uint32_t addr;
        char bytes[4];
    } fromaddr;

    if ((progname = rindex(argv[0], '/')) == NULL)
        progname = argv[0];
    else
        progname++;
    while ((ch = getopt(argc, argv, "dhl:p:r:t:n:s")) != -1)//need to modify this completely!
        switch (ch) {
            case 'r':
                dir = optarg;
                break;
            case 'd':
                soctype = SOCK_DGRAM;
                break;
            case 's':
                server = 1;
                break;
            case 'p':
                port = optarg;
                break;
            case 'h':
                host = optarg;
                break;
            case '?':
            default:
                usage();
        }
    argc -= optind;
    if (argc != 0)
        usage();
    if (!server && (host == NULL || port == NULL))
        usage();
    if (server && host != NULL)
        usage();
    /*
     * Create socket on local host.
     */
    if ((s = socket(AF_INET, soctype, 0)) < 0) {
        perror("socket");
        exit(1);
    }
    //good practice if you are implementing support for multiple clients
    if (setsockopt(s, SOL_SOCKET, SO_REUSEADDR, (char *) &opt,
            sizeof (opt)) < 0) {
        perror("setsockopt");
        exit(EXIT_FAILURE);
    }
    sock = setup_server();
    /*
     * Set up select(2) on both socket and terminal, anything that comes
     * in on socket goes to terminal, anything that gets typed on terminal
     * goes out socket...
     */
    //creating the scheduler thread
    pthread_t scheduler_thread;
    if (pthread_create(&scheduler_thread, NULL, &scheduler, 0)) {
        perror("scheduler");
        exit(1);
    }
    //creating the thread_pool
    pthread_t threads[n];
    //Could also keep a count of number of threads executing and upon termination 
    for (int i = 0; i < n; i++) {
        thread_pool.push(pthread_create(&threads[i], NULL, &worker, NULL));
    }
    while (true) {
        cerr << "Establishing Connection.." << endl;
        //accepting connections continuosly
        if (soctype == SOCK_STREAM) {
            fprintf(stderr, "Entering accept() waiting for connection.\n");
            sock = accept(s, (struct sockaddr *) &remote, &len);
        }
        cerr << "Connection established.." << endl;
        FD_ZERO(&ready);
        FD_SET(sock, &ready);

        if (select((sock + 1), &ready, 0, 0, 0) < 0) {
            printf("IF: level 1");
            perror("select");
            exit(1);
        }

        msgsize = sizeof (msgfrom);
        if (FD_ISSET(sock, &ready)) {
            cerr << "IF: level 3";
            if ((bytes = recvfrom(sock, buf, BUF_LEN, 0, (struct sockaddr *) &msgfrom, &msgsize)) <= 1) {
                done++;
            } else {// if message received from the client
                write(fileno(stdout), buf, bytes); //print it to console
                FILE_DETAILS file; //temp file_details variable to store the request parameters
                char* request = strtok(buf, " "); //split the request by space 
                file.GET = strcmp(request, "HEAD"); //check if the request is of type head or get
                request = strtok(NULL, " ");
                file.file_name = dir + string(request); //extract the file name from the request
                file.client_socket = sock; //save the socket infomartion 
                if (sjf) {
                    //set the file sizes if sjf
                    if (!file.GET)
                        file.file_size = 0;
                    else
                        dir_listing.find(file.file_name);
                } else {//if fcfs set the arrival time
                    time(&file.arv_time);
                }
                insertInQueue(&file); //insert the request in the ready queue
                //We will be responding to the client through the worker thread
                //buf[0] = 'a';
                //send(sock, buf, bytes, 0);
            }
        }
    }
    return (0);
}

void insertInQueue(FILE_DETAILS *file) {
    m.lock();
    ready_queue.push(*file); //push req in ready queue
    m.unlock();
}

void scheduler() {
    while (true) {
        m.lock();
        // ready_queue.size > 0, thread_pool,size > 0 -> pass request to worker
        if (ready_queue.size() > 1 && thread_pool.size() > 0) {
            //lock this shared variable that will store the current request being scheduled by the scheduler
            p.lock();
            pass_req = ready_queue.pop(); //initialize the shared variable to top element of the ready queue
            p.unlock();
            m.unlock();
        }
    }
}

void worker() {
    struct stat info;
    bool executing = false;
    struct HTTP_HEADER header;
    struct HTTP_RESPONSE response;
    time_t *now;
    while (true) {
        p.lock();
        if (pass_req != NULL && !executing) {
            executing = true;
            if (pass_req->GET) {//if the request id of type get, open the file
                FILE *open_file = fopen(pass_req->file_name.c_str(), "r");
                if (open_file == NULL) {
                    // response.content = dir_listing in a file (open a file in write mode)
                }
                response.content = open_file; //if the file exists add the file to content. Might have to change this!
            }
            if (stat(pass_req->file_name.c_str(), &info) != 0) {
                //get the stats for the file that was writter for directory listing in the previous step
                header.content_len = info.st_size;
                //header.content_type = get the file extension from the file name?
                header.last_modified = info.st_mtim; //timespec to time_t
                header.resp_time = time(&now);
                header.server = "whatever";
                response.header = header;
                //send the struct as text to the client
            } else {
                header.content_len = info.st_size;
                //header.content_type = get the file extension from the file name?
                header.last_modified = info.st_mtim; //timespec to time_t
                header.resp_time = time(&now);
                header.server = "whatever";
                response.header = header;
                //send the struct as text to the client
            }
        }
        executing = false;
        pass_req = NULL;
        p.unlock();
    }
    //if file.GET == true send struct HTTP_RESPONSE 
    //else send struct HTTP_HEADER
    //if file exists 
    //access the file metadata and update the header
    //open file in read mode, read file in while loop send it to client using the socket

    //else
    //return directory listing
}

/*
 * setup_server() - set up socket for mode of soc running as a server.
 */
// ======> change the root directory in this method and initialize the dir_listing

int
setup_server() {
    struct sockaddr_in serv;
    struct servent *se;
    int newsock;
    int x = chdir(dir.c_str());
    if (x != 0) {
        perror("change dir");
        exit(1);
    }
    DIR *dir;
    struct dirent *file1;
    struct stat finfo;
    if ((dir = opendir(".")) == NULL) {
        perror("list dir");
        exit(1);
    } else {
        while (file1 = readdir(dir)) {
            if (stat(file1->d_name, &finfo) != 0) {
                perror("file stat");
                exit(1);
            } else {
                dir_listing.insert({file1->d_name, finfo.st_size});
            }
        }
        (void) closedir(dir);
    }

    memset((void *) &serv, 0, sizeof (serv));

    serv.sin_family = AF_INET;
    serv.sin_addr.s_addr = INADDR_ANY;
    if (port == NULL)
        serv.sin_port = htons(8080);
    else if (isdigit(*port))
        serv.sin_port = htons(atoi(port));
    else {
        if ((se = getservbyname(port, (char *) NULL)) < (struct servent *) 0) {
            perror(port);
            exit(1);
        }
        serv.sin_port = se->s_port;
    }

    if (bind(s, (struct sockaddr *) &serv, sizeof (serv)) < 0) {
        perror("bind");
        exit(1);
    }

    if (getsockname(s, (struct sockaddr *) &remote, &len) < 0) {
        perror("getsockname");
        exit(1);
    }

    fprintf(stderr, "Port number is %d\n", ntohs(remote.sin_port));

    if (listen(s, 5) < 0) {
        perror("listen");
        exit(1);
    }

    newsock = s;

    return (newsock);
}

string formatDate(time_t * time) {
    char buffer[100];
    strftime(buffer, 100, "%a, %d %b %Y %T %Z", localtime(time));
    return buffer;
}

/*
 * usage - print usage string and exit
 */

void
usage() {
    fprintf(stderr, "usage: %s -h host -p port\n", progname);
    fprintf(stderr, "usage: %s -s [-p port]\n", progname);
    exit(1);
}